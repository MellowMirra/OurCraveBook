# OurCraveBook — Live build
- Smart parser, per-item progress, dynamic Buy Now, PPV, profiles, referrals, SEO
- Stripe checkout + webhook, Firebase (Auth/Firestore/Storage)
- Copy-link button, categories + reorder
- See README for env variables (STRIPE_*, FIREBASE_*); verify domain for Apple Pay/Google Pay
