
/** @type {import('next').NextConfig} */
const nextConfig = { reactStrictMode: true, swcMinify: true, images: { domains: ['placekitten.com','placehold.co','ourcravebook.vercel.app'] } };
module.exports = nextConfig;
